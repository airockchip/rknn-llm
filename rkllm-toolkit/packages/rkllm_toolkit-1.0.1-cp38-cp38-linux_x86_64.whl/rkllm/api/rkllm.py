from .rkllm_base import RKLLMBase

class RKLLM:
    def __init__(self, v=''):
        self.base = RKLLMBase(v)

    def load_huggingface(self, model, device='cpu'):
        """
        Load huggingface model
        :param model_path: Huggingface model path
        :param device: cuda or cpu
        :return: success: 0, failure: -1
        """
        ret = self.base.load_huggingface(model, device)
        return ret

    def build(self, do_quantization=True, optimization_level=1, quantized_dtype='w8a8', target_platform='rk3588'):
        """
        Build model to graph
        :param do_quantization: Need do quantization
        :param optimization_level: 1 do optimization, 0 not
        :param quantized_dtype: quantization type
        :param target_platform: platform type
        :return: success: 0, failure: -1
        """
        ret = self.base.build(do_quantization, optimization_level, quantized_dtype, target_platform)
        return ret

    def export_rkllm(self, export_path):
        """
        Export rknn model to file
        :param export_path: Export rkllm model path
        :return: success: 0, failure: -1
        """
        ret = self.base.export_rkllm(export_path)
        return ret